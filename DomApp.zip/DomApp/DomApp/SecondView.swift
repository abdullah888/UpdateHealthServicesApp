//
//  SecondView.swift
//  HMH App
//
//  Created by Asrar on 13/12/1444 AH.
//

import SwiftUI
//import Foundation


import LanguageManagerSwiftUI


@available(iOS 16.0, *)
struct SecondView: View {
    
    
    @State private var username = ""
    @State private var password = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var showingLoginScreen = false
    
    
    
    var body: some View {
       
         NavigationView{
           
             VStack{
                 Languagebutton()
             Image("Logo")
             .resizable()
             .opacity(0.9)
             .scaledToFit()
             .shadow(radius:6)
             .background(Color.gray.opacity(0.8))
             
           
             VStack{
             Text("Login")
             .font(.largeTitle)
             .bold()
             .padding()
             TextField("Username", text: $username)
             .padding()
             .frame(width: 300 ,height: 50)
             .background(Color.black.opacity(0.05))
             .cornerRadius(10)
             .border(.red, width: CGFloat(wrongUsername))
             
             SecureField("Password", text: $password)
             .padding()
             .frame(width: 300 ,height: 50)
             .background(Color.black.opacity(0.05))
             .cornerRadius(10)
             .border(.red, width: CGFloat(wrongPassword))
             
             //or buttoun
             NavigationLink("Login", destination:  CustomerView() )
             
             
             .foregroundColor(.white)
             .frame(width:300 ,height: 50)
             .background(Color.purple)
             .cornerRadius(10)
             Text("Don't have an account?")
             .foregroundColor(.gray)
             NavigationLink("Register", destination: RegisterView())
             .tint(.green)
         
             /*NavigationLink(destination:  Text("You are logged in @\(username)"), isActive: $showingLoginScreen){
              EmptyView()
              }*/
             }
             
             Spacer()
             
               
                    }
            
             }
       
        }
    }



  



@available(iOS 16.0, *)
struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
     
        SecondView()
       
      }
    }
    
    


