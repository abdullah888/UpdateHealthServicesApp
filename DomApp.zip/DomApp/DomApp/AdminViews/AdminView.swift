//
//  AdminView.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Firebase
struct AdminView: View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @State var color = Color("Color")
    @State var AddDoctors = false
    @State var AddSections = false
    @State var AddDoctorToSections = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack{
            VStack{
                VStack{
          
                    Text("الادارة")
                         .font(.title)
                         .fontWeight(.bold)
                         .foregroundColor(self.color)
                         .padding()
                    VStack(spacing:15){
                        Button(action: {
                            
                            self.AddSections = true
                            
                        }) {
                            Text("اضافة قسم")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                        
                        Button(action: {
                            
                            self.AddDoctors = true
                            
                        }) {
                            Text("اضافة دكتور")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                        
                        Button(action: {
                            
                            self.AddDoctorToSections = true
                            
                        }) {
                            Text("تخصيص الطبيب مع القسم")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                        
                    }
                    
                }
                Spacer()
            }
        }.sheet(isPresented: $AddSections) {
            DomApp.AddSections()
        }
        .sheet(isPresented: $AddDoctors) {
            DomApp.AddDoctors()
        }
        .sheet(isPresented: $AddDoctorToSections) {
            DomApp.AddDoctorToSections()
        }
    }
  
   
}

struct AdminView_Previews: PreviewProvider {
    static var previews: some View {
        AdminView()
    }
}
