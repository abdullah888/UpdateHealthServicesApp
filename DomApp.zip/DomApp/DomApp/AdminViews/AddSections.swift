//
//  AddSections.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Firebase
struct AddSections: View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @State var color = Color("Color")
    @State var SectionName = ""
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        ZStack{
            VStack{
                VStack{
                    Image("Logo")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 300, height: 300)
                    Text("اضافة قسم")
                         .font(.title)
                         .fontWeight(.bold)
                         .foregroundColor(self.color)
                         .padding()
                    
                        
                        TextField("اسم القسم", text: self.$SectionName)
                            .multilineTextAlignment(TextAlignment.trailing)
                            .autocapitalization(.none)
                            .padding()
                            .frame(width: UIScreen.main.bounds.width - 8)
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.SectionName != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                    
                    Button(action: {
                        
                        UploadSectionName()
                        
                    }) {
                        Text("انشاء")
                            .foregroundColor(.white)
                            .padding(.vertical)
                            .frame(width: UIScreen.main.bounds.width - 50)
                    }
                    .background(Color("Color"))
                    .cornerRadius(8)
                    .padding(.top, 25)
                    
                }
                Spacer()
            }
        }
    }
  
    func UploadSectionName(){
        let db = Firestore.firestore()
    
                    db.collection("Sections")
                        .document()
                        .setData(["ID":UUID().uuidString,"SectionName":self.SectionName]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
                    self.SectionName = ""
      
        presentationMode.wrappedValue.dismiss()
        }
}

struct AddSections_Previews: PreviewProvider {
    static var previews: some View {
        AddSections()
    }
}
