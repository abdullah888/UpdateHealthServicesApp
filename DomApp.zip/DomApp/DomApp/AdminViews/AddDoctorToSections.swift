//
//  AddDoctorToSections.swift
//  DomApp
//
//  Created by abdullah on 04/02/1445 AH.
//

import SwiftUI
import Firebase

struct AddDoctorToSections: View {
    @StateObject var DoctorToSectionstdata = DoctorToSectionsViewModel()
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @StateObject var DoctorData = DoctorsViewModel()
    @StateObject var SectionData = SectionsViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedSection = ""
    @State private var selectedDoctor = ""

    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section{
                    Picker("اختيار القسم", selection: $selectedSection) {
                        ForEach(SectionData.Sections) { section in
                            Text(section.SectionName!).tag(section.SectionName!)
                            
                        }
                    }.pickerStyle(.segmented)
                    
                    Picker("اختيار الدكتور", selection: $selectedDoctor) {
                        
                        ForEach(DoctorData.Doctors) { doctors in
                            Text(doctors.DoctorName!).tag(doctors.DoctorName!)
                        }
                    }.pickerStyle(.segmented)
                    
                }
                Section{
                    HStack{
                        Spacer()
                        Button {
                            UploadDoctorToSections()
                        } label: {
                            Text("انشاء")
                        }
                        Spacer()
                    }
                }
               
            }
            
       }
   }
    func UploadDoctorToSections(){
        let db = Firestore.firestore()
                    db.collection("DoctorToSections")
                        .document()
                        .setData(["ID":UUID().uuidString,"SectionName":self.selectedSection,"DoctorName":self.selectedDoctor]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
       
        presentationMode.wrappedValue.dismiss()
        }
}

struct AddDoctorToSections_Previews: PreviewProvider {
    static var previews: some View {
        AddDoctorToSections()
    }
}
