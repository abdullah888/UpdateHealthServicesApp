//
//  LocationManager.swift
//  DomApp
//
//  Created by abdullah on 27/01/1445 AH.
//

import UIKit
import MapKit
import CoreLocation
import Combine

class LocationManager: NSObject, ObservableObject {
    lazy var geocoder = CLGeocoder()
    
    @Published var locationString = "مستشفى المدينة الطبي"
    @Published var invalid: Bool = false
   
    func openMapWithAddress () {
        
        geocoder.geocodeAddressString(locationString) { placemarks, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.invalid = true
                }
                print(error.localizedDescription)
            }

            let coords = CLLocationCoordinate2DMake(24.44685213698835,
                                                    39.642223453971354)
            
            let place = MKPlacemark(coordinate: coords)
            
            let mapItem = MKMapItem(placemark: place)
            mapItem.name = self.locationString
            mapItem.openInMaps(launchOptions: nil)
        }
        
    }
}


