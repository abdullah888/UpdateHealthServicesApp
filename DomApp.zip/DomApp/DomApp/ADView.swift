//
//  ADView.swift
//  HMH App
//
//  Created by Asrar on 17/12/1444 AH.
//

import SwiftUI


struct ADView: View {
   var image = ["ad_1","ad_2"]
    var body: some View {
      // ScrollView(.init()){
            TabView{
                ForEach(image, id: \.self){
                    index in
                    
                    Image(index)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 250 , height: 250)
                       
                        
                   //  .blur(radius: 33)
                     // .edgesIgnoringSafeArea(.all)
                       
                }
            
                
            }
        
         // .tabViewStyle(.page)
         .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
        
    //  }
    // .ignoresSafeArea()
    }
}

struct ADView_Previews: PreviewProvider {
    static var previews: some View {
        ADView()
    }
}
