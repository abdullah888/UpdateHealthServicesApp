//
//  Cech.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI

@available(iOS 16.0, *)
struct Cech: View {
    @State var show = false
   
    @State var status = UserDefaults.standard.value(forKey: "status") as? Bool ?? false
    
    var body: some View{
        
        
        NavigationView{
            VStack{
                
                if self.status {
                    
                    CustomerView()
                 
                }else{
                    
                    ZStack{
                        
                        NavigationLink(
                            destination: SignUp(show: self.$show),
                            isActive: self.$show){
                            Text("dfdf")
                        }
                        .hidden()
                        
                        Login(show: self.$show)
                    }
                }
            }
            .navigationBarTitle("")
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
            .onAppear(){
                NotificationCenter.default.addObserver(forName: NSNotification.Name("status"), object: nil, queue: .main) { (_) in
                    
                    self.status = UserDefaults.standard.value(forKey: "status") as? Bool ?? false
                    
                }
            }
        }
    }
}

@available(iOS 16.0, *)
struct Cech_Previews: PreviewProvider {
    static var previews: some View {
        Cech()
    }
}
