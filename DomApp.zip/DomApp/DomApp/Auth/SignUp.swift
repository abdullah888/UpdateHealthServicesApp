//
//  SignUp.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI
import Firebase


struct SignUp: View {
    @State var color = Color("Color")
    @State var name = ""
    @State var phonenumber = ""
    @State var cartIDnumber = ""
    @State var email = ""
    @State var pass = ""
    @State var rePass = ""
    @State var visible = false
    @State var reVisible = false
    @Binding var show: Bool
    @State var alert = false
    @State var error = ""
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        
        ZStack{
            ZStack(alignment: .topLeading){
                GeometryReader{ _ in
                    
                    
                    VStack{
                        HStack{
                            Image("Logo")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 200, height: 200)
                            Spacer()
                            Button {
                                presentationMode.wrappedValue.dismiss()
                            } label: {
                               Text("Cancellation")
                                    .font(.body)
                                    .foregroundColor(color)
                            }
                            .padding(.leading,10)
                        }
                        
                        ScrollView(.vertical, showsIndicators: false){
                        
                        TextField("Name", text: self.$name)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.name != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                        
                        TextField("05XXXXXXXX", text: self.$phonenumber)
                            .autocapitalization(.none)
                            .keyboardType(.numberPad)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.phonenumber != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                            
                            TextField("11XXXXXXXX", text: self.$cartIDnumber)
                                .autocapitalization(.none)
                                .keyboardType(.numberPad)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 4).stroke(self.cartIDnumber != "" ? Color("Color") : self.color, lineWidth: 2))
                                .padding(.top, 25)
                        
                        TextField("Email", text: self.$email)
                            .autocapitalization(.none)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 4).stroke(self.email != "" ? Color("Color") : self.color, lineWidth: 2))
                            .padding(.top, 25)
                        
                        HStack(spacing: 15){
                            
                            VStack{
                                if self.visible {
                                    TextField("Password", text: self.$pass)
                                        .autocapitalization(.none)
                                } else {
                                    SecureField("Password" , text: self.$pass)
                                        .autocapitalization(.none)
                                }
                            }
                            
                            Button(action: {
                                self.visible.toggle()
                            }){
                                Image(systemName: self.visible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(self.color)
                                    .opacity(0.9)
                            }
                            
                            
                            
                            
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.pass != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                        
                        HStack(spacing: 15){
                            
                            
                            VStack{
                                
                                
                                if self.reVisible {
                                    TextField("Confirm the password", text: self.$rePass)
                                        .autocapitalization(.none)
                                } else {
                                    SecureField("Confirm the password" , text: self.$rePass)
                                        .autocapitalization(.none)
                                }
                            }
                            Button(action: {
                                self.reVisible.toggle()
                            }){
                                Image(systemName: self.reVisible ? "eye.slash.fill" : "eye.fill")
                                    .foregroundColor(self.color)
                                    .opacity(0.9)
                            }
                            
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).stroke(self.rePass != "" ? Color("Color") : self.color, lineWidth: 2))
                        .padding(.top, 25)
                        
                        Button(action: {
                            
                            self.register()
                            
                        }) {
                            Text("Registration")
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .frame(width: UIScreen.main.bounds.width - 50)
                        }
                        .background(Color("Color"))
                        .cornerRadius(8)
                        .padding(.top, 25)
                       }
                        
                    }
                    .padding(.horizontal ,25)
                    
                }
                
            }.navigationBarHidden(true)
            if self.alert {
                ErrorView(alert: self.$alert, error: self.$error)
                
            }
        }
        
    }
    
    
    private func register(){
        
        if self.email != "" && self.cartIDnumber != "" {
            
            if self.pass == self.rePass {
                //TextFields validated
                Auth.auth().createUser(withEmail: self.email, password: self.pass) { (res, err) in
                    if err != nil {
                        self.error = err!.localizedDescription
                        self.alert.toggle()
                        return
                    }
                    let uid = Auth.auth().currentUser?.uid
                   
                        UserModel(ID: uid!, Name: name, Phonenumber: phonenumber, CartIDnumber: cartIDnumber).Upload()
                    
                    print("success")
                    UserDefaults.standard.set(true, forKey: "status")
                    NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
                    
                }
                
                
            }else{
                self.error = "Password mismatch"
                self.alert.toggle()
            }
        } else {
            self.error = "Please fill all the contents properly"
            self.alert.toggle()
        }
        
    }
}


extension UIScreen{
   static let screenWidth = UIScreen.main.bounds.size.width
   static let screenHeight = UIScreen.main.bounds.size.height
   static let screenSize = UIScreen.main.bounds.size
}











//private func register(){
//
//    if self.email != "" && IMGData.count != 0 {
//
//        if self.password == self.passwordConfirm {
//            //TextFields validated
//            Auth.auth().createUser(withEmail: self.email, password: self.password) { (res, err) in
//                if err != nil {
//                    self.error = err!.localizedDescription
//                    self.alert.toggle()
//                    return
//                }
//                let uid = Auth.auth().currentUser?.uid
//                UploadImage(imageData: IMGData, path: "User_Image") { url in
//                    UserModel(ID: uid!, Name: name, UserImage: url).Upload()
//                }
//                print("success")
//                UserDefaults.standard.set(true, forKey: "status")
//                NotificationCenter.default.post(name: NSNotification.Name("status"), object: nil)
//
//            }
//
//
//        }else{
//            self.error = "Password mismatch"
//            self.alert.toggle()
//        }
//    } else {
//        self.error = "Please fill all the contents properly"
//        self.alert.toggle()
//    }
//
//}
