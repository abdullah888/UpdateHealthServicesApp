//
//  RegisterView.swift
//  HMH App
//
//  Created by Asrar on 16/12/1444 AH.
//

import SwiftUI

struct RegisterView: View {
    
    @State private var isSaudi = true
    //@State private var  isMale = true
    @State private var username = ""
    @State private var password = ""
    @State private var NationalID = ""
    @State private var Iqama = ""
    @State private var PhoneNamber = ""
    @State private var BirithDate = ""
    @State private var sex = ["Male","Female"]
    @State private var SelectSex = "Male"
    @State private var Sex = ""
   // @State private var BirithDate = ""
  //  @State private var BirithDate = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var showingLoginScreen = false
    
    
    
    var body: some View {
     
            NavigationView{
           
           
            VStack{
                
               
                
                Picker(selection: $isSaudi ){
                    Text("Saudi")
                        .tag(true)
                    Text("Not Saudi")
                        .tag(false)
                } label: {
                   
                }.pickerStyle(.segmented)
                
                    
            
            
            VStack{
                
                /* TextField("Sex", text: $sex)
                .padding()
                .frame(width: 300 ,height: 50)
                .background(Color.black.opacity(0.05))
                .cornerRadius(10)
               
                Picker(selection: $isMale){
                    Text("Male")
                        .tag(true)
                    Text("Female")
                }label: {
                    
                }.pickerStyle(.menu)*/
               
                
                
                if(isSaudi){
                    TextField("NationalID", text: $NationalID)
                    .padding()
                    .frame(width: 300 ,height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                }else{
                    TextField("Iqama", text: $Iqama)
                    .padding()
                    .frame(width: 300 ,height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                }
                
               
                
                TextField("Phone Namber", text: $PhoneNamber)
                .padding()
                .frame(width: 300 ,height: 50)
                .background(Color.black.opacity(0.05))
                .cornerRadius(10)
               
               
                
                
                TextField("Birith Date", text: $BirithDate)
                .padding()
                .frame(width: 300 ,height: 50)
                .background(Color.black.opacity(0.05))
                .cornerRadius(10)
                
                
            
            SecureField("Password", text: $password)
            .padding()
            .frame(width: 300 ,height: 50)
            .background(Color.black.opacity(0.05))
            .cornerRadius(10)
            
            
              
                
                
                
                
            Button("Register"){
            
            }
            .foregroundColor(.white)
            .frame(width:300 ,height: 50)
            .background(Color.purple)
            .cornerRadius(10)
               
          /* NavigationLink(destination:  Text("You are logged in @\(username)"), isActive: $showingLoginScreen){
            EmptyView()
            }*/
            }
            
            Spacer()
            
                
                   
                
            }.navigationTitle("Register")
                    
                    .navigationBarTitleDisplayMode(.inline)
                    
                    
                    
            
      
                    
                }
           
            
            }
        }


 
    
    // }
    

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
