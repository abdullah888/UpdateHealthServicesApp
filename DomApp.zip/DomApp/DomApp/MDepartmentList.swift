//
//  MDepartmentList.swift
//  HMH App
//
//  Created by Asrar on 20/12/1444 AH.
//

import SwiftUI

struct MDepartmentList: View {

    var DepList: [MDepartmentDetalis]
    var body: some View {
    NavigationView{
    ScrollView{
     
           
                
                
                
                VStack{
                    
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 15)], spacing: 20){
                        ForEach(DepList) { MDepartmentDetalis in
                        NavigationLink(destination: pressDepView(MDepartmentDetalis: MDepartmentDetalis)){
                               MDepartmentIView(MDepartmentDetalis: MDepartmentDetalis)
                            }
                        }
                    }.padding(.top)
                    
                    
                    
                        .padding(.horizontal)
                  .navigationTitle("Departments")
                    
                }
           }
        }
            }
       
}

struct MDepartmentList_Previews: PreviewProvider {
    static var previews: some View {
        ScrollView{
            MDepartmentList(DepList: MDepartmentDetalis.all)
        }
    }
}
