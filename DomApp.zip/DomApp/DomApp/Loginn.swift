//
//  Login.swift
//  HMH App
//
//  Created by Asrar on 13/12/1444 AH.
//

import SwiftUI
import LanguageManagerSwiftUI

struct Loginn: View {
    
    @State private var username = ""
    @State private var password = ""
    @State private var wrongUsername = 0
    @State private var wrongPassword = 0
    @State private var showingLoginScreen = false
    var body: some View {
        NavigationView{
            ZStack{
                Color.blue
                    .ignoresSafeArea()
                    .opacity(0.2)
                VStack{
                    
                    Text("Login")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    TextField("Username", text: $username)
                        .padding()
                        .frame(width: 300 ,height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(wrongUsername))
                    
                    SecureField("Password", text: $password)
                        .padding()
                        .frame(width: 300 ,height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(.red, width: CGFloat(wrongPassword))
                  
                    
                    Button("Login"){
                        
                    }
                    .foregroundColor(.white)
                    .frame(width:300 ,height: 50)
                    .background(Color.blue)
                    .cornerRadius(10)
                    
                /*    NavigationLink(destination:  Text("You are logged in @\(username)"), isActive: $showingLoginScreen){
                        EmptyView()
                    }*/
                    
    
                }
            }
        }
        .navigationBarHidden(true)
    }
}

struct Loginn_Previews: PreviewProvider {
    static var previews: some View {
        Loginn()
    }
}


/*struct SecondView: View {
 
 @AppStorage("language")
 
 private var language = LocalizationService.shared.language
 @State private var username = ""
 @State private var password = ""
 @State private var wrongUsername = 0
 @State private var wrongPassword = 0
 @State private var showingLoginScreen = false
 // @State private var seg: UISegmentedControl!
 // @EnvironmentObject  var languageSettings: LanguageSettings
 
 
 var body: some View {
 
 NavigationView{
 
 VStack{
 
 
 Image("Logo")
 .resizable()
 .opacity(0.9)
 .scaledToFit()
 .shadow(radius:6)
 .background(Color.gray.opacity(0.8))
 
 
 
 // .ignoresSafeArea()
 //  .offset(y: -10)
 // .background(RoundedRectangle(cornerRadius: 50).fill(.white).shadow(radius:10))
 VStack{
 Text("Login")
 .font(.largeTitle)
 .bold()
 .padding()
 TextField("Username", text: $username)
 .padding()
 .frame(width: 300 ,height: 50)
 .background(Color.black.opacity(0.05))
 .cornerRadius(10)
 .border(.red, width: CGFloat(wrongUsername))
 
 SecureField("Password", text: $password)
 .padding()
 .frame(width: 300 ,height: 50)
 .background(Color.black.opacity(0.05))
 .cornerRadius(10)
 .border(.red, width: CGFloat(wrongPassword))
 
 
 Button("Login"){
 
 }
 .foregroundColor(.white)
 .frame(width:300 ,height: 50)
 .background(Color.purple)
 .cornerRadius(10)
 Text("Don't have an account? ")
 .foregroundColor(.gray)
 Button("Register "){
 
 }
 .tint(.green)
 Text("\n")
 
 Text("Don't have a file with Hospital? ")
 .foregroundColor(.gray)
 Button("Open new file "){
 
 }
 .tint(.green)
 
 NavigationLink(destination:  Text("You are logged in @\(username)"), isActive: $showingLoginScreen){
 EmptyView()
 }
 }
 
 Spacer()
 
 }
 
 
 .toolbar{
 ToolbarItem(placement: .navigationBarLeading){
 Button(action: {
 
 }
 ,label: {
 Image(systemName: "network")
 .foregroundColor(.purple)
 })
 }
 }
 
 
 //  Image(systemName: "textformat.size")
 //    .foregroundColor(.purple)
 //  Text("Language")
 //    .foregroundColor(.purple)
 //   .bold()
 }
 }
 }
 
 // }
 */
