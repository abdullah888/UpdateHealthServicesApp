//
//  DoctorsModel.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Foundation
import Firebase

class DoctorsModel :Identifiable {
    
    var ID : String?
    var DoctorName : String?

   
   
    init(ID : String , DoctorName : String ) {
        self.ID = ID
        self.DoctorName = DoctorName
       
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.DoctorName = Dictionary["DoctorName"] as? String

       
        
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["DoctorName"] = self.DoctorName as AnyObject

       
        
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Doctors").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class DoctorsApi {
    
    
    static func GetDoctor(ID : String, completion : @escaping (_ Doctor : DoctorsModel)->()){
        
        Firestore.firestore().collection("Doctors").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = DoctorsModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllDoctors(completion : @escaping (_ Doctor : DoctorsModel)->()){
        Firestore.firestore().collection("Doctors").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = DoctorsModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}



