//
//  LocationModel.swift
//  DomApp
//
//  Created by abdullah on 10/01/1445 AH.
//

import SwiftUI
import Foundation
import Firebase

class LocationModel :Identifiable {
    
    var ID : String?
    var Location : String?
    var Time : Date?
    var userID : String?
    var userName : String?

    
    init(ID : String ,  Location : String ,  Time : Date, userID : String,userName : String) {
        self.ID = ID
        self.Location = Location
        self.Time = Time
        self.userID = userID
        self.userName = userName
   
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.Location = Dictionary["Location"] as? String
        self.Time = Dictionary["Time"] as? Date
        self.userID = Dictionary["userID"] as? String
        self.userName = Dictionary["userName"] as? String
   
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["Location"] = self.Location as AnyObject
        New["Time"] = self.Time as AnyObject
        New["userID"] = self.userID as AnyObject
        New["userName"] = self.userName as AnyObject
        
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Locations").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class LocationApi {
    
    
    static func GetLocation(ID : String, completion : @escaping (_ Location : LocationModel)->()){
        
        Firestore.firestore().collection("Locations").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = LocationModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllLocations(completion : @escaping (_ Location : LocationModel)->()){
        Firestore.firestore().collection("Locations").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = LocationModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}
