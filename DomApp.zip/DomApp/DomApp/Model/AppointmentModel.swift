//
//  AppointmentModel.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI
import Foundation
import Firebase

class AppointmentModel :Identifiable {
    
    var ID : String?
    var SectionName : String?
    var Phonenumber : String?
    var UserName: String?
    var AppointmentID : String?
    var DoctorName : String?
    var Time : Date?
   
   
    init(ID : String ,  SectionName : String , Phonenumber : String , UserName : String , AppointmentID : String , DoctorName : String , Time : Date  ) {
        self.ID = ID
        self.SectionName = SectionName
        self.Phonenumber = Phonenumber
        self.UserName = UserName
        self.AppointmentID = AppointmentID
        self.DoctorName = DoctorName
        self.Time = Time
      
    }
    
    init(Dictionary : [String : AnyObject]) {
        self.ID = Dictionary["ID"] as? String
        self.SectionName = Dictionary["SectionName"] as? String
        self.Phonenumber = Dictionary["Phonenumber"] as? String
        self.UserName = Dictionary["UserName"] as? String
        self.AppointmentID = Dictionary["AppointmentID"] as? String
        self.DoctorName = Dictionary["DoctorName"] as? String
        self.Time = Dictionary["Time"] as? Date
       
        
    }
    
    func MakeDictionary()->[String : AnyObject] {
        var New : [String : AnyObject] = [:]
        New["ID"] = self.ID as AnyObject
        New["SectionName"] = self.SectionName as AnyObject
        New["Phonenumber"] = self.Phonenumber as AnyObject
        New["UserName"] = self.UserName as AnyObject
        New["AppointmentID"] = self.AppointmentID as AnyObject
        New["DoctorName"] = self.DoctorName as AnyObject
        New["Time"] = self.Time as AnyObject
        
       
        
        return New
    }
    
    func Upload(){
        guard let id = self.ID else { return }
        Firestore.firestore().collection("Appointments").document(id).setData(MakeDictionary())
    }
    
//    func Remove(){
//        guard let id = self.ID else { return }
//        Firestore.firestore().collection("Users").document(id).delete()
//    }
    
    
    
    
}


class AppointmentApi {
    
    
    static func GetAppointment(ID : String, completion : @escaping (_ Appointment : AppointmentModel)->()){
        
        Firestore.firestore().collection("Appointments").document(ID).addSnapshotListener { (Snapshot : DocumentSnapshot?, Error : Error?) in
            
            if let data = Snapshot?.data() as [String : AnyObject]? {
               let New = AppointmentModel(Dictionary: data)
                completion(New)
            }
            
        }
        
    }
    
    static func GetAllAppointments(completion : @escaping (_ Appointment : AppointmentModel)->()){
        Firestore.firestore().collection("Appointments").getDocuments { (Snapshot, error) in
            if error != nil { print("Error") ; return }
            guard let documents = Snapshot?.documents else { return }
            for P in documents {
                if let data = P.data() as [String : AnyObject]? {
                    let New = AppointmentModel(Dictionary: data)
                    completion(New)
                }
            }
        }

    }

    
    
}



