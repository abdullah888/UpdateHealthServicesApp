//
//  AppointmentView.swift
//  HMH App
//
//  Created by Asrar on 14/12/1444 AH.
//

import SwiftUI
import Firebase

@available(iOS 16.0, *)
struct AppointmentView: View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @StateObject var profileDate = ProfileViewModel()
    @State var showAddAppointment = false
    var body: some View {
        NavigationStack{
            HStack{
                NavigationLink(destination: AddAppointmen()) {
                    Text("اضافة موعد")
                        .font(.headline)
                        .foregroundColor(Color("Color"))
                        .padding()
                }
                Spacer()
                Text("صفحة المواعيد")
                    .font(.title)
                    .foregroundColor(Color("Color"))
                    .padding()
            }
            ZStack{
                VStack{
                    List {
                        ForEach(Appointmentdata.Appointments){ appointment in
                            AppointmenCard(appintmen: appointment)
                                .buttonStyle(PlainButtonStyle())
                        }.onDelete { (index) in
                            let db = Firestore.firestore()
                            db.collection("Appointments").document(self.Appointmentdata.Appointments[index.last!].ID!).delete { (err) in
                                if err != nil{
                                    print((err?.localizedDescription)!)
                                    return
                                }
                                self.Appointmentdata.Appointments.remove(atOffsets: index)
                            }
                        }
                    }
                }
            } .onAppear(){
                Appointmentdata.fetchData()
            }
            Spacer()
        }
    }
}
          
    

@available(iOS 16.0, *)
struct AppointmentView_Previews: PreviewProvider {
    static var previews: some View {
        AppointmentView()
    }
}


struct AppointmenCard : View {
    @StateObject var Appointmentdata = AppointmentViewModel()
    @State private var showingAlert = false
    var appintmen : AppointmentModel
    var body: some View {
        VStack{
            VStack{
                VStack{
                    HStack{
                        Image("planner")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 50, height: 50)
                        Text("Name: \(appintmen.UserName!)")
                            .font(.headline)
                            .foregroundColor(Color("Color"))
                            .fontWeight(.bold)
                        Spacer()
                        VStack{
                            Text("Date:\(appintmen.Time!,style: .date)")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(Color("Color"))
                            Text("Time:\(appintmen.Time!,style: .time)")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(Color("Color"))
                        }
                    }.padding(.horizontal,20)
                VStack{
                    HStack{
                        Text("Phone: \(appintmen.Phonenumber!)")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(Color("Color"))
                        
                        Spacer()
                    }
                    HStack{
                        Text("DR : \(appintmen.DoctorName!)")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(Color("Color"))
                        Spacer()
                    }
                        HStack{
                            Text("appointment : \(appintmen.SectionName!)")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(Color("Color"))
                            Spacer()
                            HStack{
                                Button {
                                    showingAlert = true
                                } label: {
                                    Text("حذف")
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .foregroundColor(.red)
                                }
                            }
                        }
                    }.padding(.horizontal,20)
                }
            }.frame(width:UIScreen.main.bounds.width - 10,height: 100)
                .cornerRadius(15)
            Spacer()
        }.alert("للحذف اسحب للسيار", isPresented: $showingAlert) {
            Button("موافق", role: .cancel) { }
        }
        
    }
}
