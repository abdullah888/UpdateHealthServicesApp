//
//  AppButtonStyle.swift
//  HMH App
//
//  Created by Asrar on 22/12/1444 AH.
//

import SwiftUI
import LanguageManagerSwiftUI
struct AppButtonStyle: PrimitiveButtonStyle {

  func makeBody(configuration: PrimitiveButtonStyleConfiguration) -> some View {
    AppButton(configuration: configuration)
  }
    
  struct AppButton: View {
    @State var focused: Bool = false
    let configuration: PrimitiveButtonStyle.Configuration
    var body: some View {
        VStack{
            Image("language")
                .resizable()
                .scaledToFill()
                .frame(width: 35 , height: 35)
                
        }
      .scaleEffect(focused ? 1.1 : 1.0)
      .padding()
      .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
        .onChanged { _ in
            self.focused = true
        }
        .onEnded { _ in
            self.focused = false
            configuration.trigger()
        })
    }
  }
}


struct Languagebutton:View {
    @EnvironmentObject var languageSettings: LanguageSettings
    var body: some View {
        HStack{
       
            Spacer()
            
            if languageSettings.selectedLanguage == .en {
                HStack{
                    Button("") {
                        languageSettings.selectedLanguage = .ar
                    }
                }
            } else if languageSettings.selectedLanguage == .ar {
                HStack{
                    Button("") {
                        languageSettings.selectedLanguage = .en
                    }
                }
            }
      }.buttonStyle(AppButtonStyle())
    }
}
