//
//  LocationVieww.swift
//  DomApp
//
//  Created by abdullah on 27/01/1445 AH.
//

import SwiftUI

struct LocationVieww: View {
    @ObservedObject var Hospitallocation = LocationManager()
    var body: some View {
        VStack{
            Button {
                Hospitallocation.openMapWithAddress()
            } label: {
                HStack{
                    Image("place")
                        .resizable()
                        .frame(width: 40, height: 40)
                }
            }
        }.onAppear(){
            Hospitallocation.invalid = false
            Hospitallocation.locationString = "مستشفى المدينة الطبي"
        }
    }
}

struct LocationVieww_Previews: PreviewProvider {
    static var previews: some View {
        LocationVieww()
    }
}
