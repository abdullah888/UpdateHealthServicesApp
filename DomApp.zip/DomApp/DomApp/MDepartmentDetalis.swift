//
//  MDepartmentDetalis.swift
//  HMH App
//
//  Created by Asrar on 20/12/1444 AH.
//

import SwiftUI
import Foundation

enum detalis : String {
    case outpatientClinics = "Outpatient Clinics"
    case laboratory = " Laboratory"
    case xray = " Xray"
    case physiotherapy = " Physiotherapy"
    case surgeries = " Surgeries"
    case dialysis = " Dialysis"
}
struct MDepartmentDetalis: Identifiable{
    let id = UUID()
    let name: String
    let image: String
    let morDetails: String
    
}

extension MDepartmentDetalis{
    static let all: [MDepartmentDetalis] = [
        MDepartmentDetalis( name: "Laboratory", image: "LAB", morDetails: "Mor abuot lab")
        ,MDepartmentDetalis(name:"Xray" , image: "xray", morDetails: "Mor abuot Xray")
        ,MDepartmentDetalis(name: "Physiotherapy", image: "physi" ,morDetails: "Mor abuot Physiotherapy")
        ,MDepartmentDetalis(name: "Dialysis", image: "DIALSIS",  morDetails: "Mor abuot Dialysis")
    ]
}


