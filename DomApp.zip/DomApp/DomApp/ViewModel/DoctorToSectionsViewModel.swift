//
//  DoctorToSectionsViewModel.swift
//  DomApp
//
//  Created by abdullah on 03/02/1445 AH.
//

import SwiftUI
import CoreLocation
import Firebase
import UIKit
import MapKit
import Combine

class DoctorToSectionsViewModel: ObservableObject{
  
    
    //Modell
    @Published var DoctorToSections: [DoctorToSectionsModel] = []
    @Published  var SectionName = ""
    @Published  var DoctorName = ""
 
 
    
    @AppStorage("current_status") var status = false
    
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
     init() {
      
        fetchDoctorToSectionsData()
    }
    
    
    //غير مستخدم
    func GetDoctorToSectionsData(){
        ref.collection("DoctorToSections").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}
            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    DoctorToSectionsApi.GetDoctorToSections(ID: doc.document.documentID) { DoctorToSections in
                        self.DoctorToSections.append(DoctorToSections)
                    }
                }
            }
        }
    }
    
    
    func fetchDoctorToSectionsData(){
        
        let db = Firestore.firestore()
        
        db.collection("DoctorToSections").getDocuments { (snap, err) in
            
            guard let doctorToSectionsData = snap else{return}
            
            self.DoctorToSections = doctorToSectionsData.documents.compactMap({ (doc) -> DoctorToSectionsModel? in
                let ID = doc.documentID
                let SectionName = doc.get("SectionName") as! String
                let DoctorName = doc.get("DoctorName") as! String
       
                return DoctorToSectionsModel(ID: ID, SectionName: SectionName, DoctorName: DoctorName)
                  })
            DispatchQueue.main.async {
                self.DoctorToSections = self.DoctorToSections
            }
        }
    }
    
    func deleteLocation(id: String){
        let ref = Firestore.firestore()
        ref.collection("DoctorToSections").document(id).delete { (err) in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
        }
    }
    func Delete(){
        DoctorToSections.forEach { (i) in
            deleteLocation(id: i.ID!)
        }
    }
    
    
    
}
