//
//  DoctorsViewModel.swift
//  DomApp
//
//  Created by abdullah on 02/02/1445 AH.
//

import SwiftUI
import Firebase

class DoctorsViewModel : ObservableObject{
  
    //Modell
    @Published var Doctors: [DoctorsModel] = []
    @Published  var DoctorName = ""
    
  
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
    init() {
        GetDoctors()
   
    }
// غير مستخدم
    func UploadDoctor(){
        let db = Firestore.firestore()
        Auth.auth().addStateDidChangeListener { auth, user in
            if let id = user?.uid{
                UserApi.GetUser(ID: id) { User in
                    db.collection("Doctors")
                        .document()
                        .setData(["DoctorName":self.DoctorName]) { (err) in
                            if err != nil{
                                print((err?.localizedDescription)!)
                                return
                                   }
                               }
                    self.DoctorName = ""
           
                    }
                }
            }
       
        }
   

    func GetDoctors(){
        ref.collection("Doctors").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    DoctorsApi.GetDoctor(ID: doc.document.documentID) { Doctor in
                        self.Doctors.append(Doctor)
                    }
                   
                }
            }
        }
    }
    
    func NewGetDoctors() {
        
        let db = Firestore.firestore()
        
        db.collection("Doctors").addSnapshotListener { (snap, err) in
            
            if err != nil{
                
                print((err?.localizedDescription)!)
                return
            }
            
            for i in snap!.documentChanges{
                
                
                if i.type == .added{
                    
                    let id = i.document.documentID
                    let DoctorName = i.document.get("DoctorName") as! String
                    self.Doctors.append(DoctorsModel(ID: id,DoctorName: DoctorName))
                }
                
            }
        }
    }
     
    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Doctors").getDocuments { (snap, err) in
            
            guard let DoctorsData = snap else{return}
            
            self.Doctors = DoctorsData.documents.compactMap({ (doc) -> DoctorsModel? in
                
                
                
                let id = doc.documentID
                let DoctorName = doc.get("DoctorName") as! String
          
                return DoctorsModel(ID: id,DoctorName: DoctorName)

            })
            
            self.Doctors = self.Doctors
        }
    }
}
