//
//  AppointmentViewModel.swift
//  DomApp
//
//  Created by abdullah on 02/01/1445 AH.
//

import SwiftUI
import Firebase

class AppointmentViewModel : ObservableObject{
  
    //Modell
    @Published var Appointments: [AppointmentModel] = []

  
    let ref = Firestore.firestore()
    let uiD = Auth.auth().currentUser?.uid
    
    init() {
        fetchData()
    }

    
    
    func GetAppointment(){
        ref.collection("Appointments").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}

            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    AppointmentApi.GetAppointment(ID:  doc.document.documentID) { Appointment in
                        if Appointment.AppointmentID == self.uiD {
                            self.Appointments.append(Appointment)
                        }
                    }
                }
            }
        }
    }
    
    func NewGetAppointment() {
         
         let db = Firestore.firestore()
     
         db.collection("Appointments").addSnapshotListener { (snap, err) in
             
             if err != nil{
                 
                 print((err?.localizedDescription)!)
                 return
             }
             
             for i in snap!.documentChanges{
             
                   
                         if i.type == .added{
                             
                             let id = i.document.documentID
                             let SectionName = i.document.get("SectionName") as! String
                             let Phonenumber = i.document.get("Phonenumber") as! String
                             let UserName = i.document.get("UserName") as! String
                             let AppointmentID = i.document.get("AppointmentID") as! String
                             let DoctorName = i.document.get("DoctorName") as! String
                             let Time = i.document.get("Time") as! Timestamp
                             self.Appointments.append(AppointmentModel(ID: id, SectionName: SectionName, Phonenumber: Phonenumber, UserName: UserName, AppointmentID: AppointmentID,DoctorName: DoctorName,Time: Time.dateValue()))
                         }
                     
                     }
                 }
             
          
        
     }

    func fetchData(){
        
        let db = Firestore.firestore()
        
        db.collection("Appointments").getDocuments { (snap, err) in
            
            guard let AppointmentData = snap else{return}
            
            self.Appointments = AppointmentData.documents.compactMap({ (doc) -> AppointmentModel? in
                
                
                
                let id = doc.documentID
                let SectionName = doc.get("SectionName") as! String
                let Phonenumber = doc.get("Phonenumber") as! String
                let UserName = doc.get("UserName") as! String
                let AppointmentID = doc.get("AppointmentID") as! String
                let DoctorName = doc.get("DoctorName") as! String
                let Time = doc.get("Time") as! Timestamp
                return AppointmentModel(ID: id, SectionName: SectionName, Phonenumber: Phonenumber, UserName: UserName, AppointmentID: AppointmentID,DoctorName: DoctorName,Time: Time.dateValue())
           
                
                
            })
            DispatchQueue.main.async {
                self.Appointments = self.Appointments
            }
        }
    }
    
    func deleteAppointment(id: String){
        let ref = Firestore.firestore()
        
        ref.collection("Appointments").document(id).delete { (err) in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
        }
    }
    func Delete(){
        Appointments.forEach { (i) in
            deleteAppointment(id: i.ID!)
        }
    }
    
}
