//
//  LocationViewModel.swift
//  DomApp
//
//  Created by abdullah on 10/01/1445 AH.
//

import SwiftUI
import CoreLocation
import Firebase
import UIKit
import MapKit
import Combine

class LocationViewModel: NSObject,ObservableObject,CLLocationManagerDelegate{
    //Location
      lazy var geocoder = CLGeocoder()
      @Published var invalid: Bool = false
      @Published var locationManager = CLLocationManager()
      @Published var userLocation : CLLocation!
      @Published var userAddress = ""
      @Published var noLocation = false
    
       //Modell
       @Published var location: [LocationModel] = []
       @Published  var Location = ""
       @Published  var userID = ""
       @Published  var userName = ""
  
       @AppStorage("current_status") var status = false

       let ref = Firestore.firestore()
       let uiD = Auth.auth().currentUser?.uid
       
    override init() {
        super.init()
        fetchLocationData()
       }
   
    
    //غير مستخدم
    func GetLocation(){
        ref.collection("Locations").addSnapshotListener { snap, err in
            if err != nil{
                print(err!.localizedDescription)
                return
            }
            guard let data = snap else{return}
            data.documentChanges.forEach { (doc) in
                if doc.type == .added{
                    LocationApi.GetLocation(ID:  doc.document.documentID) { Location in
                        if Location.userID == self.uiD {
                            self.location.append(Location)
                        }
                    }
                
                }
            }
        }
    }
       

       func fetchLocationData(){
           
           let db = Firestore.firestore()
           
           db.collection("Locations").getDocuments { (snap, err) in
               
               guard let LocationData = snap else{return}
               
               self.location = LocationData.documents.compactMap({ (doc) -> LocationModel? in
                  
                   let ID = doc.documentID
                   let Location = doc.get("Location") as! String
                   let Time = doc.get("Time") as! Timestamp
                   let userID = doc.get("userID") as! String
                   let userName = doc.get("userName") as! String
                   return LocationModel(ID: ID, Location: Location, Time: Time.dateValue(), userID: userID,userName:userName )})
            DispatchQueue.main.async {
                   self.location = self.location
               }
           }
       }
       
       func deleteLocation(id: String){
           let ref = Firestore.firestore()
           ref.collection("Locations").document(id).delete { (err) in
               if err != nil{
                   print(err!.localizedDescription)
                   return
               }
           }
       }
       func Delete(){
           location.forEach { (i) in
               deleteLocation(id: i.ID!)
           }
       }
 
  //location
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
    
        // checking Location Access....
        
        switch manager.authorizationStatus {
        case .authorizedWhenInUse:
            print("authorized")
            self.noLocation = false
            manager.requestLocation()
        case .denied:
            print("denied")
            self.noLocation = true
        default:
            print("unknown")
            self.noLocation = false
            // Direct Call
            locationManager.requestWhenInUseAuthorization()
            // Modifying Info.plist...
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // reading User Location And Extracting Details....
        
        self.userLocation = locations.last
        self.extractLocation()
        // after Extracting Location Logging In....
      
    }
    
    func extractLocation(){
        
        CLGeocoder().reverseGeocodeLocation(self.userLocation) { (res, err) in
            
            guard let safeData = res else{return}
            
            var address = ""
            
            // getting area and locatlity name....
            
            address += safeData.first?.name ?? ""
            address += ", "
            address += safeData.first?.locality ?? ""
            DispatchQueue.main.async {
                self.userAddress = address
            }
        }
    }
   
    func openMapWithAddresss () {
        
        geocoder.geocodeAddressString(self.Location) { placemarks, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.invalid = true
                }
                print(error.localizedDescription)
            }
            
            guard let placemark = placemarks?.first else {
                return
            }
            
            guard let lat = placemark.location?.coordinate.latitude else{return}
            
            guard let lon = placemark.location?.coordinate.longitude else{return}
            
            let coords = CLLocationCoordinate2DMake(lat, lon)
            
            let place = MKPlacemark(coordinate: coords)
            
            let mapItem = MKMapItem(placemark: place)
            mapItem.name = self.Location
            mapItem.openInMaps(launchOptions: nil)
        }
        
    }

}
